package com.example.music_notato

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
